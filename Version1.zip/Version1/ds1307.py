class DS1307:
    def __init__(self, i2c):
        self.i2c = i2c
        self.addr = 0x68  # DS1307 I2C address

    def _bcd_to_dec(self, bcd):
        return (bcd // 16) * 10 + (bcd % 16)

    def _dec_to_bcd(self, dec):
        return (dec // 10) * 16 + (dec % 10)

    def get_time(self):
        try:
            # Try to read 7 bytes starting at register 0x00
            data = self.i2c.readfrom_mem(self.addr, 0x00, 7)
            seconds = self._bcd_to_dec(data[0] & 0x7F)
            minutes = self._bcd_to_dec(data[1])
            hours = self._bcd_to_dec(data[2])
            return (hours, minutes, seconds)
        except Exception as e:
            print("Failed to read from RTC:", e)
            raise

    def set_time(self, hours, minutes, seconds=0):
        try:
            # Write time in BCD format to DS1307
            self.i2c.writeto_mem(self.addr, 0x00, bytearray([
                self._dec_to_bcd(seconds),
                self._dec_to_bcd(minutes),
                self._dec_to_bcd(hours)
            ]))
        except Exception as e:
            print("Failed to set time:", e)
            raise
